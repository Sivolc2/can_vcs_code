import AIVCWorkflow from "@/components/AIVCWorkflow"

// rest of the code will go here.  This is a placeholder.  The prompt did not provide any existing code.
export default function MyComponent() {
  return (
    <div>
      <AIVCWorkflow />
    </div>
  )
}

